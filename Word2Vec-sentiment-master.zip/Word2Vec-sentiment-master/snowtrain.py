import sys
import importlib
importlib.reload(sys)
import pandas as pd
from snownlp import sentiment
from snownlp import SnowNLP
# from snownlp import SnowNLP

sentiment.train('D:/python工作区/Test2/venv/Lib/site-packages/snownlp/sentiment/neg.txt', 'D:/python工作区/Test2/venv/Lib/site-packages/snownlp/sentiment/pos.txt') #对语料库进行训练，把路径改成相应的位置。我这次练习并没有构建语料库，用了默认的，所以把路径写到了sentiment模块下。
sentiment.save('D:/python工作区/Test2/venv/Lib/site-packages/snownlp/sentiment.marshal')#这一步是对上一步的训练结果进行保存，如果以后语料库没有改变，下次不用再进行训练，直接使用就可以了，所以一定要保存，保存位置可以自己决定，但是要把`snownlp/seg/__init__.py`里的`data_path`也改成你保存的位置，不然下次使用还是默认的。
import numpy as np
import pandas as pd
import jieba
from gensim.models import word2vec
from sklearn.model_selection import train_test_split
import codecs,sys,re


#读入数据
# 创建停用词list
def stopwordslist(filepath):
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords

# 清洗文本
def clearTxt(line):
    if line != '':
        line = line.strip()
        #去除文本中的英文和数字
        line = re.sub("[a-zA-Z0-9]","",line)
        #去除文本中的中文符号和英文符号
        line = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "",line)
    return line

stopwords = stopwordslist('./data/stop_char.txt')  # 这里加载停用词的路径

pos = pd.read_table('./data/pos.csv',header=None,index_col=None)
neg = pd.read_table('./data/neg.csv',header=None,index_col=None)
print(pos.head())

#保存数据
def save_data(doc_path,data):
    np.save(doc_path,data)

#数据处理
def process(pos_and_neg):
    final_pos_and_neg = []
    for sent in pos_and_neg:
        clearsent = clearTxt(sent)  # 进行数据清洗
        cutsent = jieba.lcut(clearsent)  # 切分清洗后的文本
        newsent = []
        for word in cutsent:  # 去除停用词
            if word not in stopwords:
                if word != '\t':
                    newsent.append(word)
        final_pos_and_neg.append(newsent)
    print(final_pos_and_neg)
    return final_pos_and_neg

#分词
pos['c_w'] = [sent for sent in pos[0]]
neg['c_w'] = [sent for sent in neg[0]]

#合并neg和pos
pos_and_neg = np.append(pos['c_w'],neg['c_w'],axis=0)

#对训练语料进行处理
final_pos_and_neg=process(pos_and_neg)

#构造对应的标签数组
table = np.append((np.ones(len(pos))),(np.zeros(len(neg))),axis=0)
print(table.shape)

#切分训练集合测试集
x_train,x_test,y_train,y_test = train_test_split(final_pos_and_neg,table,test_size=0.01)


text=pd.read_excel(u'./data/评论文本.xlsx',header=None,index_col=None) #读取文本数据
r_text=text.iloc[:,0] #提取所有数据
text1=[i.encode('utf-8').decode('utf-8') for i in r_text] #上一步提取数据不是字符而是object，所以在这一步进行转码为字符
r_y_test=text.iloc[:,1]
r_x_test=process(r_text)
print(r_x_test)

x_train_data = save_data('./data/x_train_data.npy',x_train)
x_test_data = save_data('./data/x_test_data.npy',r_x_test)
y_train_data = save_data('./data/y_train_data.npy',y_train)
y_test_data = save_data('./data/y_test_data.npy',r_y_test)
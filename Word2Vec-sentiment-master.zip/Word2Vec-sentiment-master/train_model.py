#coding:utf-8

import numpy as np
import pandas as pd
from gensim.models import word2vec
from sklearn.svm import SVC
from sklearn.externals import joblib

#下载数据
#def get_data():
train_vec = np.load('./data/train_vec.npy')
test_vec = np.load('./data/test_vec.npy')
y_train =np.load('./data/y_train_data.npy')
y_test = np.load('./data/y_test_data.npy')
#训练SVM模型
def svm_tran(train_vec,y_train,test_vec,y_test):
    clf = SVC(kernel='rbf',verbose=True)
    clf.fit(train_vec,y_train)
    #持久化保存模型
    joblib.dump(clf,'./svm_model/svm_model.pkl',compress=3)
    print("模型score:",clf.score(test_vec,y_test))

svm_tran(train_vec,y_train,test_vec,y_test)
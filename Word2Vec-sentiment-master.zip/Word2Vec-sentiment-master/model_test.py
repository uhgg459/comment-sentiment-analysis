#coding:utf-8

import sys
import importlib
importlib.reload(sys)
import numpy as np
import pandas as pd
from gensim.models import word2vec
from sklearn.svm import SVC
from sklearn.externals import joblib
from model import get_sent_vec
import jieba
import codecs,sys,re
# 精准率与召回率
from sklearn.metrics import precision_score, recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix

#下载数据
model = word2vec.Word2Vec.load('./data/train_model.model')
clf = joblib.load('./svm_model/svm_model.pkl')

# 创建停用词list
def stopwordslist(filepath):
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords

# 清洗文本
def clearTxt(line):
    if line != '':
        line = line.strip()
        #去除文本中的英文和数字
        line = re.sub("[a-zA-Z0-9]","",line)
        #去除文本中的中文符号和英文符号
        line = re.sub("[\s+\.\!\/_,$%^*(+\"\'；：“”．]+|[+——！，。？?、~@#￥%……&*（）]+", "",line)
    return line

stopwords = stopwordslist('./data/stop_char.txt')  # 这里加载停用词的路径

# #对单个句子进行情感判断
# def svm_predict(sent):
#     sent_cut = jieba.lcut(sent)
#     sent_cut_vec = get_sent_vec(300,sent_cut,model)
#     result = clf.predict(sent_cut_vec)
#     print(result[0])
#
#     if int(result[0] == 1):
#         print(sent,'积极')
#     else:
#         print(sent,'消极')

def get_svm_predict(sent):
    clearsent=clearTxt(sent)  # 进行数据清洗
    sent_cut = jieba.lcut(clearsent)
    newsent = []
    for word in sent_cut:#去除停用词
        if word not in stopwords:
            if word != '\t':
                newsent.append(word)
    sent_cut_vec = get_sent_vec(300,newsent,model)
    result = clf.predict(sent_cut_vec)
    if int(result[0] == 1):
        return 1
    else:
        return 0

#情感正式开始预测

text=pd.read_excel(u'./data/评论文本.xlsx',header=None,index_col=None) #读取文本数据
text0=text.iloc[:,0] #提取所有数据
text1=[i.encode('utf-8').decode('utf-8') for i in text0] #上一步提取数据不是字符而是object，所以在这一步进行转码为字符

newsenti = []
for i in text1:
    newsenti.append(get_svm_predict(i))
text['predict']=newsenti #将新的预测标签增加为text的某一列，所以现在text的第0列为评论文本，第1列为实际标签，第2列为预测标签
counts=0
for j in range(len(text.iloc[:,0])): #遍历所有标签，将预测标签和实际标签进行比较，相同则判断正确。
  if text.iloc[j,2]==text.iloc[j,1]:
    counts+=1
print(u"准确率为:%f"%(float(counts)/float(len(text))))#输出本次预测的准确率

print('-========')
print("精确率:",precision_score(text.iloc[:,1], text.iloc[:,2]))
print('-========')
print("召回率:",recall_score(text.iloc[:,1],text.iloc[:,2]))
print('-========')
print("f1值:",f1_score(text.iloc[:,1],text.iloc[:,2]))